package com.cg.swpp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.swpp.dto.Customer;
import com.cg.swpp.dto.Transaction;

@Repository("customerdao")
public class CustomerDaoImpl implements ICustomerDao{

	@PersistenceContext
	EntityManager em;
	
	
	@Override
	@Transactional
	public void createAccount(Customer customer) {
		
		Transaction trans = new Transaction();
		em.persist(customer);	
		trans.setMobileno(customer.getMobile_no());;
		trans.setAmount(0);
		trans.setBalance(customer.getInit_bal());
		trans.setCod("Credit");
		em.persist(trans);
		em.flush();
		
	}

	@Override
	@Transactional
	public double deposit(String mobileNo, double amount) {
		Transaction trans = new Transaction();
		Customer c = em.find(Customer.class, mobileNo);
		double amt = c.getInit_bal();
		amt = amt+amount;
		c.setInit_bal(amt);
		trans.setMobileno(mobileNo);
		trans.setAmount(amount);
		trans.setBalance(amt);
		trans.setCod("Credit");
		em.persist(trans);
		em.flush();
		return amt;
	}

	@Override
	@Transactional
	public double withdraw(String mobileNo, double amount) {
		Transaction trans = new Transaction();
		Customer c = em.find(Customer.class, mobileNo);
		double amt =c.getInit_bal();
		amt=amt-amount;
		c.setInit_bal(amt);
		trans.setMobileno(mobileNo);
		trans.setAmount(amount);
		trans.setBalance(amt);
		trans.setCod("Debit");
		em.persist(trans);
		em.flush();
		return amt;
	}

	@Override
	public double checkBalance(String mobileNo) {
		Customer c = em.find(Customer.class, mobileNo);
		return c.getInit_bal();
	}

	@Override
	public boolean accountVal(String mobileNo) {
		Customer c1= em.find(Customer.class, mobileNo);
		if(c1 != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public double fundTransfer(String mobno1, double amt, String mobno2) {
		Transaction trans = new Transaction();
		Customer c= em.find(Customer.class, mobno1);
		Customer c1= em.find(Customer.class, mobno2);
		double amount1 = c.getInit_bal() - amt;
		double amount2 = c1.getInit_bal() + amt;
		c.setInit_bal(amount1);
		c1.setInit_bal(amount2);
		Transaction trans1 = new Transaction();
		trans.setMobileno(mobno1);
		trans.setAmount(amt);
		trans.setBalance(amount1);
		trans.setCod("Debit");
		trans1.setMobileno(mobno2);
		trans1.setAmount(amt);
		trans1.setBalance(amount2);
		trans1.setCod("Credit");
		em.persist(trans);
		em.persist(trans1);
		em.flush();		
		return amount1;
	}

	@Override
	public boolean withdrawVal(String mobileNo, double amount) {
		Customer c = em.find(Customer.class, mobileNo);
		double amt = c.getInit_bal();
		if(amt-amount<500)
			return false;
		else
			return true;
	}

	@Override
	public List<Transaction> getTransList(String mobileNo) {
		String qr = "select t from Transaction t where mobileno ="+mobileNo;
		TypedQuery<Transaction> query = em.createQuery(qr, Transaction.class);
		List<Transaction> list = query.getResultList();
		return list;
	}

}
