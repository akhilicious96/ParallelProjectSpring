package com.cg.swpp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.swpp.dao.ICustomerDao;
import com.cg.swpp.dto.Customer;
import com.cg.swpp.dto.Transaction;


@Service("customerservice")
@Transactional
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerdao;
	
	@Override
	public void createAccount(Customer customer) {
		customerdao.createAccount(customer);
		
	}

	@Override
	public double deposit(String mobileNo, double amount) {
		return customerdao.deposit(mobileNo, amount);	
	}

	@Override
	public double withdraw(String mobileNo, double amount) {
		return customerdao.withdraw(mobileNo, amount);
	}

	@Override
	public double checkBalance(String mobileNo) {
		return customerdao.checkBalance(mobileNo);
	}

	@Override
	public boolean accountVal(String mobileNo) {
		return customerdao.accountVal(mobileNo);
	}

	@Override
	public double fundTransfer(String mobno1, double amt, String mobno2) {
		return customerdao.fundTransfer(mobno1, amt, mobno2);
	}

	@Override
	public boolean withdrawVal(String mobileNo, double amount) {
		return customerdao.withdrawVal(mobileNo, amount);
	}

	@Override
	public List<Transaction> getTransList(String mobileNo) {
		return customerdao.getTransList(mobileNo);
	}
	
	
	
}
