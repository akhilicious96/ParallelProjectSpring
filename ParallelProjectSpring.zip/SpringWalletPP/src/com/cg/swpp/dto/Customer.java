package com.cg.swpp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table
public class Customer {

	@Column
	private String name;
	
	@Id
	@Column
	private String mobile_no;
	
	@Column
	private float age;
	
	@Column
	private double init_bal;
	
	@Transient
	private double amount;
	
	@Transient
	private String mobNo;

	public Customer() {
		super();		
	}

	public Customer(String name, String mobile_no, float age, double init_bal) {
		super();
		this.name = name;
		this.mobile_no = mobile_no;
		this.age = age;
		this.init_bal = init_bal;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public float getAge() {
		return age;
	}

	public void setAge(float age) {
		this.age = age;
	}

	public double getInit_bal() {
		return init_bal;
	}

	public void setInit_bal(double init_bal) {
		this.init_bal = init_bal;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	
	
	
}
