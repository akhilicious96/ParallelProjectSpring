package com.cg.swpp.service;

import java.util.List;

import com.cg.swpp.dto.Customer;
import com.cg.swpp.dto.Transaction;

public interface ICustomerService {

public void createAccount(Customer customer);
	
	public double deposit(String mobileNo, double amount);
	
	public double withdraw(String mobileNo, double amount);
	
	public double checkBalance(String mobileNo);

	public boolean accountVal(String mobileNo);

	public double fundTransfer(String mobno1, double amt, String mobno2);

	public boolean withdrawVal(String mobileNo, double amount);

	List<Transaction> getTransList(String mobileNo);
	
}
