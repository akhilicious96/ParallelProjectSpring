package com.cg.swpp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.swpp.dto.Customer;
import com.cg.swpp.dto.Transaction;
import com.cg.swpp.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService customerservice;
	
	@RequestMapping(value="/addcustomer", method=RequestMethod.GET)
	public String getAllCust(Model model) {
		System.out.println("AddCustomer");
		model.addAttribute("add",new Customer());
		return "AddCustomer";	 
	}
	
	@RequestMapping(value="adddata", method=RequestMethod.POST)
	public String addMobileData(@ModelAttribute("add") Customer cust){
		customerservice.createAccount(cust);
		return "success";
	}
	
	
	@RequestMapping(value="/deposit")
	public String deposit(@ModelAttribute("dep") Customer cust){
		return "deposit";
	}
	
	@RequestMapping(value="depositamount", method = RequestMethod.POST)
	public ModelAndView depositAmount(@ModelAttribute("dep") Customer cust){
		if(customerservice.accountVal(cust.getMobile_no())){
			double amt = customerservice.deposit(cust.getMobile_no(), cust.getInit_bal());
			return new ModelAndView("DepositAmount", "newBal", amt);
		}
		else
			return new ModelAndView("AccountNotFound", "name", "");
	}
	
	@RequestMapping(value="/withdraw")
	public String withdrawAmount(@ModelAttribute("withdraw") Customer cust){
		return "displaywithdraw";
	}
	
	@RequestMapping(value="withdrawamount", method=RequestMethod.POST )
	public ModelAndView withdrawAmt(@Valid@ModelAttribute("with") Customer cust){
		if(customerservice.accountVal(cust.getMobile_no())){
			if(customerservice.withdrawVal(cust.getMobile_no(), cust.getAmount())){
				double amt=customerservice.withdraw(cust.getMobile_no(), cust.getAmount());
				return new ModelAndView("WithdrawSuccess", "newBal",amt);
			}
			else
				return new ModelAndView("WithdrawFail");
		}
		else
			return new ModelAndView("AccountNotFound", "name", "");
	}
	
	
	@RequestMapping(value="/balancecheck")
	public String checkBalance(@ModelAttribute("checkBalance") Customer cust){
		return "checkBalance";
		
	}
	
	@RequestMapping(value="checkBal", method=RequestMethod.POST)
	public ModelAndView checkbal(@Valid@ModelAttribute("chk") Customer cust){
		if(customerservice.accountVal(cust.getMobile_no())){
			 double amt = customerservice.checkBalance(cust.getMobile_no());
			 return new ModelAndView("CheckBalanceSuccess", "newBal",amt);
		}
		else
			return new ModelAndView("AccountNotFound", "name", "");
	}		
	
	
	@RequestMapping(value="/fundtransfer")
	public String fundTransfer(@ModelAttribute("fund") Customer cust){
		return "FundTransfer";
	}
	
	@RequestMapping(value="fundtrans", method = RequestMethod.POST)
	public ModelAndView fundtransfer(@Valid@ModelAttribute("fund") Customer cust){
		if(customerservice.accountVal(cust.getMobile_no())){
			if(customerservice.accountVal(cust.getMobNo())){
				if(customerservice.withdrawVal(cust.getMobile_no(), cust.getAmount())){
					double amt1=customerservice.fundTransfer(cust.getMobile_no(), cust.getAmount(), cust.getMobNo());
					return new ModelAndView("TransferSuccess", "newBal",amt1);
				}
				else
					return new ModelAndView("WithdrawFail");				
			}
			else
				return new ModelAndView("AccountNotFound" , "name", "receiver's");
		}
		else
			return new ModelAndView("AccountNotFound" , "name", "sender's");
	}
	
	
	@RequestMapping(value="/printTransaction")
	public String showTransaction(@ModelAttribute("transaction") Customer cust){
		return "Transaction";
	}
	
	@RequestMapping(value="printtransaction", method= RequestMethod.POST)
	public ModelAndView transList(@Valid@ModelAttribute("transaction") Customer cust){
		if(customerservice.accountVal(cust.getMobile_no())){
			List<Transaction> list = customerservice.getTransList(cust.getMobile_no());
			 return new ModelAndView("PrintTransaction", "list", list);
		}
		else
			return new ModelAndView("AccountNotFound", "name", "");
	}
}
